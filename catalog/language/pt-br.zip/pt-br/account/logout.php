<?php
// Heading
$_['heading_title'] = 'Sair';

// Text
$_['text_message']  = '<p>Você saiu de sua conta. Esse é o método mais seguro para que ninguém acesse sua conta.</p> <p>A sua sacola de compras foi salva, os itens dentro dela serão restaurados assim que você acessar sua conta novamente.</p>';
$_['text_account']  = 'Minha conta';
$_['text_logout']   = 'Sair';