<?php
// Text
$_['text_title'] = 'Pagar ao retirar na loja';