<?php
// Heading
$_['heading_title'] = 'Opções de filtro';