<?php
// Text
$_['text_subject']  = 'Você recebeu um vale presentes de %s';
$_['text_greeting'] = 'Parabéns! Você acaba de receber um vale presentes de %s.';
$_['text_from']     = 'Quem lhe enviou este vale presentes foi %s.';
$_['text_message']  = 'O vale presentes veio com a seguinte mensagem:';
$_['text_redeem']   = 'Para utilizar este vale presentes, anote o código <b>%s</b>, depois acesse o link abaixo e escolha os produtos que você deseja comprar. Você deve inserir o código do vale presentes na página da sacola de compras, antes de finalizar o pedido.';
$_['text_footer']   = 'Caso tenha alguma dúvida, responda este e-mail.';