<?php
// Text
$_['text_subject']  = '%s - Solicitação de nova senha';
$_['text_greeting'] = 'Uma nova senha foi solicitada através da loja %s.';
$_['text_change']   = 'Para redefinir sua senha, clique no link abaixo:';
$_['text_ip']       = 'O IP utilizado para solicitar a nova senha foi: %s';