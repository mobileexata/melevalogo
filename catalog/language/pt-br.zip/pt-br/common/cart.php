<?php
// Text
$_['text_items']     = '%s';
$_['text_empty']     = 'Sua sacola está vazia.';
$_['text_cart']      = 'Exibir sacola';
$_['text_checkout']  = 'Finalizar pedido';
$_['text_recurring'] = 'Assinatura';